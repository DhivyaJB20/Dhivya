package assesment;
import java.util.*;


public class RecentlyPlayedStore {
	    private final int initialCapacity;
	    private final Map<String, LinkedList<String>> userPlaylists;

	    public RecentlyPlayedStore(int initialCapacity) {
	        this.initialCapacity = initialCapacity;
	        this.userPlaylists = new HashMap<>();
	    }

	    public void playSong(String user, String song) {
	        LinkedList<String> playlist = userPlaylists.computeIfAbsent(user, k -> new LinkedList<>());

	        if (playlist.contains(song)) {
	            playlist.remove(song); // Remove the song if it's already in the playlist
	        } else if (playlist.size() >= initialCapacity) {
	            playlist.removeFirst(); // Remove the least recently played song if the playlist is full
	        }

	        playlist.addLast(song); // Add the newly played song to the end of the playlist
	    }

	    public List<String> getPlaylist(String user) {
	        return userPlaylists.getOrDefault(user, new LinkedList<>());
	    }
	}

	

